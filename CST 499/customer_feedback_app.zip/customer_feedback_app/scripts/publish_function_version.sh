#!/usr/bin/env bash

# Use this script to publish a version of a function to a function alias.
# For example, you could publish version 1 of a function to the 'dev' alias
# to deploy version 1 to the Customer Feedback App's 'dev' environment.

PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null && pwd )"
FUNCTIONS=( "persistCustomerFeedback" "serveCustomerFeedbackFiles" )
ALIASES=( "dev" "qa" "v1" )
SELECTED_FUNCTION=""
SELECTED_ALIAS=""

select_function() {
  echo -e "\n\nSelect the Lambda function to update:"
  select opt in "${FUNCTIONS[@]}"
  do
    if [[ "${FUNCTIONS[@]} | grep -wq $opt" ]]
    then
      SELECTED_FUNCTION=${opt}
      echo -e "\nYou chose $SELECTED_FUNCTION"
      break;
    else
      echo "Invalid selection"
    fi
  done
}

update_alias() {
  echo -e "\n\nSelect the alias to update:"
  select opt in "${ALIASES[@]}"
  do
    if [[ "${ALIASES[@]} | grep -wq $opt" ]]
    then
      SELECTED_ALIAS=${opt}
      echo -e "\nYou chose $SELECTED_FUNCTION"
      break;
    else
      echo "Invalid selection"
    fi
  done

  echo -e "\n\nHere is a list of existing function versions:"
  aws lambda list-versions-by-function \
    --function-name "${SELECTED_FUNCTION}"
  read -p "Enter the function version number: " version

  aws lambda update-alias \
    --function-name "${SELECTED_FUNCTION}" \
    --name "${SELECTED_ALIAS}" \
    --function-version "${version}"
}

select_function
update_alias
