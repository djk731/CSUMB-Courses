#!/usr/bin/env bash

# Use this script to deploy changes to the AWS resource stack after you
# change the SAM template (template.yml).

echo -e "\n\nBe certain you have logged into AWS using \"okta2aws login\"\n\n"
PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null && pwd )"
cd  "${PROJECT_ROOT}/server"

sam package \
 --s3-bucket customerfeedbackwidget \
 --template-file template.yml \
 --output-template-file customerFeedBack-template.yml

sam deploy \
  --template-file customerFeedBack-template.yml \
  --stack-name customerFeedbackStack \
  --capabilities CAPABILITY_IAM

rm customerFeedBack-template.yml
