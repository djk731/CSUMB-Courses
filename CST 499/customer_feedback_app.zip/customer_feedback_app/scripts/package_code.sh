#!/usr/bin/env bash

# Use this script to generate a build artifact for each Lambda function,
# based on the code you have locally, and to deploy those artifacts to
# S3 for later import into the Lambda functions.

echo -e "\n\nBe certain you have logged into AWS using \"okta2aws login\"\n\n"
PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null && pwd )"
LAMBDA_FUNCTIONS=( "serveCustomerFeedbackFiles" "persistCustomerFeedback" )

cd "${PROJECT_ROOT}/client"
echo "Compiling React app"
npm run build
echo -e "\n\nCopying React app into Lambda function\n\n"
cp build/static/js/main.js ../server/serveCustomerFeedbackFiles/

echo "Packaging and deploying Lambda functions"
for i in "${LAMBDA_FUNCTIONS[@]}"
do
  cd "${PROJECT_ROOT}/server/${i}"
  rm -rf ./node_modules
  echo "Creating a production build for ${i}..."
  npm install --production
  zip -r ${i}.zip . -x node_modules/aws-sdk/\*
  echo "Deploying build artifact ${i}.zip to S3..."
#  aws s3 cp ${i}.zip s3://customerfeedbackwidget/
#  rm ${i}.zip
  echo "Reinstating dev dependencies..."
  npm install
done
