#!/usr/bin/env bash

# Use this script to deploy code changes to a Lambda function, and optionally
# to publish a new version of the function.
# Note that the changes pushed by this function will not be mapped to any
# of the aliases of the Lambda function until you run the
# `publish_function_version.sh` script.

PROJECT_ROOT="$( cd "$( dirname "${BASH_SOURCE[0]}" )/.." >/dev/null && pwd )"
FUNCTIONS=( "persistCustomerFeedback" "serveCustomerFeedbackFiles" )
SELECTED_FUNCTION=""

package_code() {
  echo -e "\n\n"
  read -p "Package and deploy local code to S3 (y|n)? [n] " package
  if [[ "$package" = "y" ]]
  then
    ${PROJECT_ROOT}/scripts/package_code.sh
  fi
}

select_function() {
  echo -e "\n\nSelect which Lambda function to update:\n\n"
  select opt in "${FUNCTIONS[@]}"
  do
    case "$REPLY" in

    1 )
      SELECTED_FUNCTION=${opt}
      echo -e "You chose $SELECTED_FUNCTION\n\n"
      break
      ;;
    2 )
      SELECTED_FUNCTION=${opt}
      echo -e "You chose $SELECTED_FUNCTION\n\n"
      break;;
    * )
      echo "Invalid selection"
      break
      ;;
    esac
  done
}

deploy_code() {
  aws lambda update-function-code \
    --function-name "${SELECTED_FUNCTION}" \
    --s3-bucket customerfeedbackwidget \
    --s3-key "${SELECTED_FUNCTION}.zip"

  echo -e "\n\n"
  read -p "Publish new version of function (y|n)? [y] " new_version
  if [[ "$new_version" != "n" ]]
  then
    read -p "Enter a description for the new version: " version_description
    aws lambda publish-version \
      --function-name "${SELECTED_FUNCTION}" \
      --description "${version_description}"
  fi
}

echo -e "\n\nBe certain you have logged into AWS using \"okta2aws login\""
package_code
select_function
deploy_code
