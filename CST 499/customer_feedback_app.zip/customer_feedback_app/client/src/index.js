import React from 'react';
import ReactDOM from 'react-dom';
import './index.css';
import registerServiceWorker from './registerServiceWorker';
import Feedback from './components/Feedback/Feedback';
import './fonts/index.css';

/**
 * Dynamically insert a mount point into the DOM and attach React app to it.
 */
function insertMountPoint() {
  const mountPointId = 'customer-feedback';
  const mountPoint = document.createElement('div');
  const body = document.getElementsByTagName('body')[0];

  /**
   * Callback function for DOM mutation observer.
   *
   * Mounts the React app once the mount point has been added to the document
   * body.
   *
   * @param mutationList
   *   The list of DOM mutations occurring since instantiation of the observer.
   * @param observer
   *   The DOM MutationObserver object using this callback.
   */
  const observerCallback = function observerCallback(mutationList, observer) {
    mutationList.forEach((mutation) => {
      if (mutation.type === 'childList') {
        const addedNode = mutation.addedNodes[0];
        if (typeof addedNode !== 'undefined' && addedNode.getAttribute('id') === mountPointId) {
          ReactDOM.render(<Feedback />, document.getElementById(mountPointId));
          // Once the React app has been attached, stop listening for further
          // DOM mutation events.
          observer.disconnect();
        }
      }
    });
  };
  // Instantiate a DOM mutation observer to watch for DOM changes and trigger
  // the callback function when mutations occur.
  const observer = new MutationObserver(observerCallback);

  mountPoint.setAttribute('id', mountPointId);
  // Start watching for insertions into the body element.
  observer.observe(body, { childList: true, attributes: false, subtree: true });
  // Insert the mount point into the body.
  body.appendChild(mountPoint);
}

// Insert the mount point and React app on document ready event.
document.addEventListener('DOMContentLoaded', insertMountPoint);
// Register a service worker to optimize offline experience.
registerServiceWorker();
