import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './Button.css';

class Button extends Component {
  constructor(props) {
    super(props);
    this.onClick = this.onClick.bind(this);
  }

  onClick(event) {
    const {
      clickHandler,
    } = this.props;
    clickHandler(event);
  }

  render() {
    const {
      type,
      name,
      className,
      label,
      alt,
      disabled,
    } = this.props;

    switch (type) {
    case 'submit':
      return (
        <input
          type="submit"
          name={name}
          value={label}
          className={`${styles[className]} ${styles.button}`}
          onClick={this.onClick}
          alt={alt}
          disabled={disabled}
        />
      );

    case 'button':
    default:
      return (
        <button
          type="button"
          name={name}
          className={`${styles.button} ${styles[className]}`}
          onClick={this.onClick}
          disabled={disabled}
        >
          {label}
        </button>
      );
    }
  }
}

Button.propTypes = {
  type: PropTypes.string.isRequired,
  name: PropTypes.string.isRequired,
  className: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  alt: PropTypes.string.isRequired,
  disabled: PropTypes.bool,
  clickHandler: PropTypes.func,
};

Button.defaultProps = {
  clickHandler: () => {},
  disabled: false,
};

export default Button;
