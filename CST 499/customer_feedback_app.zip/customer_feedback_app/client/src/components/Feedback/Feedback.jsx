import React, { Component } from 'react';
import update from 'immutability-helper';
import axios from 'axios';
import JssProvider from 'react-jss/lib/JssProvider';
import { create } from 'jss';
import { jssPreset } from '@material-ui/core/styles';
import MuiButton from '@material-ui/core/Button';
import Popper from '@material-ui/core/Popper';
import Button from '../Button/Button';
import styles from './Feedback.css';
import FeedbackComment from '../FeedbackComment/FeedbackComment';
import checkmark from '../../images/thank-you-cloud.png';

const styleNode = document.createComment('jss-insertion-point');
document.head.insertBefore(styleNode, document.head.firstChild);

const jss = create({
  jssPreset,
  // We define a custom insertion point that JSS will look for injecting the styles in the DOM.
  insertionPoint: 'jss-insertion-point',
});

// Default API endpoint for POST requests if there is no getApiEndpoint()
// function available.
const defaultApiEndpoint = '/voc/qa/customer-feedback';

class Feedback extends Component {
  constructor(props) {
    super(props);

    // The website that is loading this script may define a global
    // WdCustomerFeedback variable that contains extraData populated
    // by the application and, in the future, additional configuration
    // options to pass to the React application.
    this.customConfig = global.WdCustomerFeedback || {};
    const extraData = this.customConfig.extraData || {};

    this.initialState = {
      submitted: false,
      formValues: {
        helpful: '',
        feedback_comment: '',
        extraData,
      },
      anchorEl: null,
      open: false,
      sadWithResults: false,
    };
    this.handleFeedbackFormChange = this.handleFeedbackFormChange.bind(this);
    this.resetForm = this.resetForm.bind(this);
    this.handleFeedbackFormSubmit = this.handleFeedbackFormSubmit.bind(this);
    this.handleHappySadButtonClicks = this.handleHappySadButtonClicks.bind(this);
    this.handleFeedbackButtonClick = this.handleFeedbackButtonClick.bind(this);
    this.handleCloseButtonClick = this.handleCloseButtonClick.bind(this);
    // The serveCustomerFeedbackFiles lambda function will attempt to append
    // a getApiEndpoint() function to the compiled React application, which
    // will return the URL to the endpoint from which the app was served. If
    // that function is not appended for some reason, fall back to the
    // defaultApiEndpoint.
    if (typeof global.getApiEndpoint === 'function') {
      this.apiEndpoint = global.getApiEndpoint();
    } else {
      this.apiEndpoint = defaultApiEndpoint;
    }
    this.state = this.initialState;
  }

  handleFeedbackButtonClick = (event) => {
    const { currentTarget } = event;
    const { open } = this.state;

    this.toggleFeedbackCloseButtonHelper(!open, currentTarget);
  };

  handleFeedbackFormSubmit(event) {
    if (event) {
      event.preventDefault();
    }

    const stateToSubmit = this.state;

    // Feedback comment not allowed for happy clicks.
    if (stateToSubmit.formValues.helpful === 'yes') {
      delete stateToSubmit.formValues.feedback_comment;
    }

    // Submit the form via ajax here.
    axios.post(this.apiEndpoint, stateToSubmit.formValues, {
      headers: { 'x-api-key': '4Be7hIf93q5LcYbw53siR6kUSYk7K3he26sYmv7f' },
    })
    // Return the response object without making further changes.
      .then(res => res)
      // Return the error object.
      .catch(error => error);
    // Reset the form with the 'submitted' state value set to true.
    this.resetForm(true);
  }

  handleFeedbackFormChange(stateProperty, event) {
    let value = '';
    if (stateProperty === 'feedback_comment') {
      /* eslint-disable */
      value = event.target.value;
      /* eslint-enable */
      // Dont let submission of empty strings
      if (String.prototype.trim.call(value) === '') {
        value = '';
      }
    }

    const stateChange = {
      formValues: {},
    };
    stateChange.formValues[stateProperty] = { $set: value };
    const newState = update(this.state, stateChange);
    this.setState(newState);
  }

  handleHappySadButtonClicks(feeling) {
    const stateChange = {
      formValues: {},
    };
    if (feeling === 'happy') {
      stateChange.formValues.helpful = { $set: 'yes' };
      stateChange.submitted = { $set: true };
      stateChange.sadWithResults = { $set: false };
    } else if (feeling === 'sad') {
      stateChange.formValues.helpful = { $set: 'no' };
      stateChange.submitted = { $set: false };
      stateChange.sadWithResults = { $set: true };
    } else {
      return;
    }
    const newState = update(this.state, stateChange);
    if (feeling === 'happy') {
      this.setState(newState, () => this.handleFeedbackFormSubmit());
    } else {
      this.setState(newState);
    }
  }

  resetForm(submitted = false) {
    const prevState = this.state;
    // We dont reset the form data so we can test out the
    // data sent to AWS.
    const stateChange = {
      open: submitted,
      submitted,
      sadWithResults: false,
    };
    const resetState = Object.assign(prevState, stateChange);
    this.setState(resetState);
  }

  handleCloseButtonClick() {
    this.toggleFeedbackCloseButtonHelper();
  }

  /**
   * Helper method for toggling feedback button and clicking the close button.
   */
  toggleFeedbackCloseButtonHelper(open, anchorEl) {
    let openParam;
    if (typeof (open) === 'undefined') {
      openParam = false;
    } else {
      openParam = open;
    }
    // When this method is called from the close button click,
    // the popper should be closed always.
    // When called from the feedback button click, the popper
    // should be toggled.
    let newState = Object.assign(this.state, {
      open: openParam,
      sadWithResults: false,
      formValues: {
        helpful: '',
        feedback_comment: '',
        extraData: this.customConfig.extraData || {},
      },
    });
    // The Anchor element is needed when feedback button is clicked.
    if (!(typeof (anchorEl) === 'undefined')) {
      newState = Object.assign(newState, { anchorEl });
    }
    this.setState(newState);
  }

  render() {
    const {
      submitted, formValues, anchorEl, open, sadWithResults,
    } = this.state;

    const popperContent = [];
    popperContent.closeButton = (
      <Button
        name="closeButton"
        type="button"
        label=""
        className="button--close"
        clickHandler={this.handleCloseButtonClick}
        alt="Close the popper"
      />
    );

    if (submitted) {
      popperContent.body = (
        <div className={`${styles.feedback__container}`}>
          <img src={checkmark} alt="" className={`${styles.feedback__topmargin}`} />
          <div className={`${styles['feedback__thank-you-header-container']}`}>
            <p className={`${styles['feedback__header-text']} ${styles.feedback__text}`}>
              Thanks for letting
            </p>
            <p className={`${styles['feedback__header-text']} ${styles.feedback__text}`}>
              us know!
            </p>
          </div>
          <div className={`${styles['feedback__text-container']}`}>
            <p className={`${styles['feedback__body-text']} ${styles.feedback__text}`}>
                Your feedback will help improve our business.
            </p>
          </div>
        </div>
      );
    } else if (sadWithResults) {
      popperContent.body = (
        <div className={`${styles.feedback__container} ${styles['feedback__text-area-container']}`}>
          <form onSubmit={this.handleFeedbackFormSubmit}>
            <FeedbackComment
              name="feedback_comment"
              className="feedback-comment"
              label="What went wrong?"
              value={formValues.feedback_comment}
              handleCommentChange={event => this.handleFeedbackFormChange('feedback_comment', event)}
            />
            <Button
              type="button"
              name="submit"
              className={formValues.feedback_comment.length === 0 ? 'button--submit__disabled' : 'button--submit__enabled'}
              disabled={formValues.feedback_comment.length === 0}
              label="Submit"
              clickHandler={this.handleFeedbackFormSubmit}
              alt="Submit"
            />
          </form>
        </div>
      );
    } else {
      popperContent.body = (
        <div>
          <div className={`${styles['feedback__did-you-find-header-container']}`}>
            <p className={`${styles['feedback__header-text']} ${styles.feedback__text}`}>
                Did you find what you were looking for?
            </p>
          </div>
          <form onSubmit={this.handleSubmit}>
            <div className={`${styles['feedback__happy-sad-container']}`}>
              <Button
                name="happyButton"
                type="button"
                label=""
                className="button--happy"
                clickHandler={() => this.handleHappySadButtonClicks('happy')}
                alt="Happy With Search Results"
              />
              <Button
                name="sadButton"
                type="button"
                label=""
                className="button--sad"
                clickHandler={() => this.handleHappySadButtonClicks('sad')}
                alt="unHappy With Search Results"
              />
            </div>
          </form>
        </div>
      );
    }

    return (
      <JssProvider jss={jss}>
        <div>
          <div className={`${styles.feedback}`}>
            <MuiButton
              classes={{
                root: `${open ? styles['feedback__button--active'] : styles.feedback__button}`,
                label: `${styles['feedback__button-text']}`,
              }}
              variant="contained"
              onClick={this.handleFeedbackButtonClick}
              disableRipple
            >
              Share Your Feedback
            </MuiButton>
            <Popper
              disablePortal
              open={open}
              anchorEl={anchorEl}
              placement="top-end"
              className={submitted ? `${styles['feedback__popper--active']}` : `${styles.feedback__popper}`}
              modifiers={{
                flip: {
                  enabled: false,
                },
              }}
            >
              {popperContent.closeButton}
              {popperContent.body}
            </Popper>
          </div>
        </div>
      </JssProvider>
    );
  }
}

export default Feedback;
