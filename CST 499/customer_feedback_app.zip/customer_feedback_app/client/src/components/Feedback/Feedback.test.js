import React from 'react';
import { mount } from 'enzyme';
import Feedback from './Feedback';

describe('<Feedback />', () => {
  let app;
  let feedbackButton;
  let assertStateData;
  beforeEach(() => {
    app = mount(<Feedback />);
    feedbackButton = app.find('Button');
    assertStateData = function assertData(state) {
      // Helper function that asserts current state values
      // for the key value pairs that are passed as argument.
      Object.entries(state).forEach((entry) => {
        const [key, value] = entry;
        if (typeof (value) === 'object') {
          expect(app.state(key)).toEqual(expect.objectContaining(value));
        } else {
          expect(app.state(key)).toBe(value);
        }
      });
    };
  });

  test('State is populated with extraData', () => {
    // Mock the WdCustomerFeedback global variable.
    global.WdCustomerFeedback = {
      extraData: {
        submissionType: 'SearchFeedback',
        url: 'example.html',
        pageName: 'ReactApp',
        userId: 1234,
        orgId: 9876,
        userRole: 456,
        searchPhrase: 'gdpr',
      },
    };

    // App needs to be remounted to set extraData.
    app = mount(<Feedback />);

    expect(app.state('formValues').extraData).toEqual(global.WdCustomerFeedback.extraData);
    // Unset the WdCustomerFeedback global variable
    // so that it does not persist to subsequent tests.
    global.WdCustomerFeedback = undefined;
  });

  test('Button has the correct label', () => {
    expect(feedbackButton.text()).toBe('Share Your Feedback');
  });

  test('Form expands from collapsed state', () => {
    // Assert expectation of our initial app state.
    assertStateData({ open: false });
    // Simulate expanding the panel.
    feedbackButton.simulate('click');
    // Assert expectation of current app state.
    assertStateData({ open: true });
    // Simulate a 2nd button click - should stay open.
    feedbackButton.simulate('click');
    // Assert expectation of current app state.
    assertStateData({ open: false });
    // Assert that the formValues object is empty since
    // nothing has been submitted to AWS yet.
    assertStateData({
      formValues: {
        helpful: '',
        feedback_comment: '',
        extraData: {},
      },
    });
  });

  test('Expanded panel shows happy and sad buttons', () => {
    // Assert expectation of our initial app state.
    assertStateData({ open: false, submitted: false, sadWithResults: false });
    // Simulate a click on the panel header.
    feedbackButton.simulate('click');
    // Assert that the Happy and Sad Buttons are displayed.
    const happyButton = app.find('.button--happy');
    const sadButton = app.find('.button--sad');
    expect(happyButton).not.toBeNull();
    expect(sadButton).not.toBeNull();
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: false, sadWithResults: false });
    // Assert that the formValues object is empty since
    // nothing has been submitted to AWS yet.
    assertStateData({
      formValues: {
        helpful: '',
        feedback_comment: '',
        extraData: {},
      },
    });
  });

  test('Happy button click displays thank-you message', () => {
    // Assert expectation of our initial app state.
    assertStateData({ open: false, submitted: false, sadWithResults: false });
    // Simulate click on 'Share your feedback button' to expand the panel.
    feedbackButton.simulate('click');
    // Simulate click on the happy button.
    app.find('.button--happy').simulate('click');
    // Assert that the Thank you screen is shown.
    expect(app.html()).toEqual(expect.stringContaining('Thanks for letting'));
    expect(app.html()).toEqual(expect.stringContaining('us know!'));
    expect(app.html()).toEqual(expect.stringContaining('Your feedback will help improve our business'));
    // Assert app state now.
    assertStateData({ open: true, submitted: true, sadWithResults: false });
    // Assert formValues data that will be sent to AWS from UI.
    assertStateData({
      formValues: {
        helpful: 'yes',
        extraData: {},
      },
    });
  });

  test('Sad button click and feedback form functionality', () => {
    // Assert expectation of our initial app state.
    assertStateData({ open: false, submitted: false, sadWithResults: false });
    // Simulate click on 'Share your feedback button' to expand the panel.
    feedbackButton.simulate('click');
    // Simulate click on the sad button.
    app.find('.button--sad').simulate('click');
    // Assert that feedback form screen is shown.
    expect(app.html()).toEqual(expect.stringContaining('What went wrong?'));
    // Assert that the text are for feedback submission is shown.
    const feedbackCommentTextArea = app.find('textarea[name="feedback_comment"]');
    expect(feedbackCommentTextArea).not.toBeNull();
    // Assert app state now.
    assertStateData({ open: true, submitted: false, sadWithResults: true });
    // Assert that the submit button is disabled when the feedback comment
    // field is empty.
    let submitButton = app.find('Button[name="submit"]');
    expect(submitButton).not.toBeNull();
    expect(submitButton.is('[disabled]')).toBe(true);
    // Assert that the submit button is enabled when the feedback comment
    // field is populated.
    feedbackCommentTextArea.instance().value = 'Feedback is simply great, i clicked the sad button by mistake';
    feedbackCommentTextArea.simulate('change');
    submitButton = app.find('Button[name="submit"]');
    expect(submitButton.props().disabled).toBe(false);
    // Empty the text area again and assert that the submit button is disabled.
    feedbackCommentTextArea.instance().value = '';
    feedbackCommentTextArea.simulate('change');
    submitButton = app.find('Button[name="submit"]');
    expect(submitButton.props().disabled).toBe(true);
    // Enter text again and submit the form.
    feedbackCommentTextArea.instance().value = 'Feedback is simply great, i clicked the sad button by mistake';
    feedbackCommentTextArea.simulate('change');
    submitButton = app.find('Button[name="submit"]');
    submitButton.simulate('submit');
    // Assert that feedback form submission displays a thank you message.
    expect(app.html()).toEqual(expect.stringContaining('Thanks for letting'));
    expect(app.html()).toEqual(expect.stringContaining('us know!'));
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: true, sadWithResults: false });
    // Assert formValues data sent to AWS from UI.
    assertStateData({
      formValues: {
        helpful: 'no',
        feedback_comment: feedbackCommentTextArea.instance().value,
        extraData: {},
      },
    });
  });

  test('Sad screen closing and opening the popper again', () => {
    // Assert expectation of our initial app state.
    assertStateData({ open: false, submitted: false, sadWithResults: false });
    // Simulate click on 'Share your feedback button' to expand the panel.
    feedbackButton.simulate('click');
    // Simulate click on the sad button.
    app.find('.button--sad').simulate('click');
    const closeButton = app.find('.button--close');
    expect(closeButton.length, 1);
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: false, sadWithResults: true });
    // Close the popper.
    closeButton.simulate('click');
    expect(app.state('open')).toBe(false);
    // Open again.
    feedbackButton.simulate('click');
    // Now the happy sad buttons should be shown , not the
    // sad screen again.
    const happyButton = app.find('[name="happyButton"]');
    const sadButton = app.find('[name="sadButton"]');
    expect(happyButton).not.toBeNull();
    expect(sadButton).not.toBeNull();
    expect(app.html()).not.toEqual(expect.stringContaining('What went wrong?'));
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: false, sadWithResults: false });
    // Form values should be empty now as form has been close
    // and screen is defaulted to the happy sad screen.
    assertStateData({
      formValues: {
        helpful: '',
        feedback_comment: '',
        extraData: {},
      },
    });
    // Close popper again by clicking on feedback button.
    feedbackButton.simulate('click');
    assertStateData({ open: false, submitted: false, sadWithResults: false });
    // Open again by clicking on the feedback button.
    feedbackButton.simulate('click');
    assertStateData({ open: true, submitted: false, sadWithResults: false });
    // The happy sad screen should be shown now.
    expect(happyButton).not.toBeNull();
    expect(sadButton).not.toBeNull();
  });

  test('Sad screen closing, opening the popper and clicking happy button', () => {
    // Assert expectation of our initial app state.
    assertStateData({ open: false, submitted: false, sadWithResults: false });
    expect(feedbackButton.length, 1);
    // Simulate click on 'Share your feedback button' to expand the panel.
    feedbackButton.simulate('click');
    // Simulate click on the sad button.
    app.find('.button--sad').simulate('click');
    expect(app.state('sadWithResults')).toBe(true);
    // Simulate entering text in the feedback form.
    const feedbackCommentTextArea = app.find('textarea[name="feedback_comment"]');
    feedbackCommentTextArea.instance().value = 'Feedback is simply great, i clicked the sad button by mistake';
    expect(feedbackCommentTextArea.length, 1);
    feedbackCommentTextArea.simulate('change');
    const closeButton = app.find('.button--close');
    expect(closeButton.length, 1);
    // Close the popper.
    closeButton.simulate('click');
    expect(app.state('open')).toBe(false);
    // Open popper again.
    expect(feedbackButton.length, 1);
    feedbackButton.simulate('click');
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: false, sadWithResults: false });
    // Closing the sad screen and opening again should show
    // the happy sad buttons, not the sad screen again.
    const happyButton = app.find('.button--happy');
    expect(happyButton.length).toEqual(1);
    // Click the happy button now.
    happyButton.simulate('click');
    // Assert expected Thank you screen text in the popper.
    expect(app.html()).toEqual(expect.stringContaining('Thanks for letting'));
    expect(app.html()).toEqual(expect.stringContaining('us know!'));
    expect(app.html()).toEqual(expect.stringContaining('Your feedback will help improve our business'));
    expect(app.html()).not.toEqual(expect.stringContaining('What went wrong?'));
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: true, sadWithResults: false });
    // Assert formValues data that will be sent to AWS from UI.
    assertStateData({
      formValues: {
        helpful: 'yes',
        extraData: {},
      },
    });
    // Now close popper using the feedback button.
    feedbackButton.simulate('click');
    // Popper should not be shown.
    expect(app.html()).not.toEqual(expect.stringContaining('Thanks for letting'));
    assertStateData({ open: false, submitted: true, sadWithResults: false });
  });

  test('Feedback panel can be closed with the close button or clicking on feedback button', () => {
    // Simulate opening and closing the widget twice,
    // once with the close button and second with toggling the feedback button.
    // Open the popper.
    feedbackButton.simulate('click');
    const closeButton = app.find('.button--close');
    expect(closeButton.length, 1);
    const buttonsThatCanClose = [closeButton, feedbackButton];
    buttonsThatCanClose.forEach((button) => {
      // Close the popper using the button being looped.
      button.simulate('click');
      // Assert expectation of current app state.
      assertStateData({ open: false, submitted: false, sadWithResults: false });
      // Open again by clicking on feedback button.
      feedbackButton.simulate('click');
      // Assert expectation of current app state.
      assertStateData({ open: true, submitted: false, sadWithResults: false });
      // Need to get the button node again  as React cannot
      // recognize the close button anymore when referenced with
      // 'button' variable.
      // Close popper using the button being looped again.
      if (button.props('name') === 'closeButton') {
        closeButton.simulate('click');
      } else {
        feedbackButton.simulate('click');
      }
      // Open the popper.
      feedbackButton.simulate('click');
    });
  });

  test('Thank you panel has working close button', () => {
    // Open the popper.
    feedbackButton.simulate('click');
    const happyButton = app.find('.button--happy');
    const closeButton = app.find('.button--close');
    // Click the happy face.
    happyButton.simulate('click');
    // Assert that the thank you screen is shown.
    expect(app.html()).toEqual(expect.stringContaining('Thanks for letting'));
    expect(app.html()).toEqual(expect.stringContaining('us know!'));
    // Assert expectation of current app state.
    assertStateData({ open: true, submitted: true, sadWithResults: false });
    // Click the close button.
    closeButton.simulate('click');
    expect(closeButton.length, 0);
    // Assert expectation of current app state.
    assertStateData({ open: false, submitted: true, sadWithResults: false });
    // Open the popper again.
    feedbackButton.simulate('click');
    expect(app.state('open')).toBe(true);
    // Click feedback button again - thank you panel should be closed.
    feedbackButton.simulate('click');
    // Assert expectation of current app state.
    assertStateData({ open: false, submitted: true, sadWithResults: false });
  });
});
