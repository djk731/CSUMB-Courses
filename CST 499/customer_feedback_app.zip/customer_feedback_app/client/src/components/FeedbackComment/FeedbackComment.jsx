import React, { Component } from 'react';
import PropTypes from 'prop-types';
import styles from './FeedbackComment.css';

class FeedbackComment extends Component {
  constructor(props) {
    super(props);
    this.onChange = this.onChange.bind(this);
  }

  onChange(event) {
    const { handleCommentChange } = this.props;
    handleCommentChange(event);
  }

  render() {
    const {
      name,
      className,
      label,
      value,
    } = this.props;

    return (
      <div className={`${styles[className]} ${styles['feedback-comment']}`}>
        <span className={`${styles[className]} ${styles['feedback-comment__label']}`}>
          {label}
        </span>
        <textarea
          name={name}
          rows="8"
          cols="50"
          value={value}
          onChange={this.onChange}
        />
      </div>
    );
  }
}

FeedbackComment.propTypes = {
  name: PropTypes.string.isRequired,
  className: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  value: PropTypes.string,
  handleCommentChange: PropTypes.func.isRequired,
};

FeedbackComment.defaultProps = {
  value: '',
};

export default FeedbackComment;
