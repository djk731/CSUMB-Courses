import React, { Component } from 'react';
import PropTypes from 'prop-types';
import { Radio, RadioGroup } from 'react-radio-group';
import styles from './RadioButtons.css';

class RadioButtons extends Component {
  constructor(props) {
    super(props);

    this.onChange = this.onChange.bind(this);
  }

  onChange(event) {
    const {
      handleRadioChange,
    } = this.props;
    handleRadioChange(event);
  }

  render() {
    const {
      name,
      question,
      values,
      error,
      selectedValue,
    } = this.props;

    const options = values.map((value) => {
      const label = value.charAt(0).toUpperCase() + value.slice(1);
      return (
        <span
          key={value}
          className={`${styles['radio-button']}${error ? ` ${styles.error}` : ''}`}
        >
          <Radio value={value} />
          {label}
        </span>
      );
    });

    return (
      <RadioGroup name={name} selectedValue={selectedValue} onChange={this.onChange}>
        <div className={`${styles.question}`}>
          {question}
        </div>
        {options}
        {error ? (
          <p className={`${styles.error}`}>
            You must select an option.
          </p>
        ) : ('')
        }
      </RadioGroup>
    );
  }
}

RadioButtons.propTypes = {
  name: PropTypes.string.isRequired,
  question: PropTypes.string.isRequired,
  values: PropTypes.arrayOf(PropTypes.string).isRequired,
  error: PropTypes.bool.isRequired,
  selectedValue: PropTypes.oneOfType([
    PropTypes.bool,
    PropTypes.string,
    PropTypes.number,
  ]),
  handleRadioChange: PropTypes.func,
};

RadioButtons.defaultProps = {
  selectedValue: '',
  handleRadioChange: () => {},
};

export default RadioButtons;
