# Overview

# Installing this project

Go to the client directory
```
cd into /customer-feedback/client
```
Install dependencies with Yarn
```
yarn install
```
To start development and see changes in the browser run:
```
yarn start
```

