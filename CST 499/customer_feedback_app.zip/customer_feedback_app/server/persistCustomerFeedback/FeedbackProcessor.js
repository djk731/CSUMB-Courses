const uuidv4 = require('uuid/v4');
const Joi = require('joi');
const createDOMPurify = require('dompurify');
const { JSDOM } = require('jsdom');

const { window } = (new JSDOM(''));
const DOMPurify = createDOMPurify(window);
// Configure the sanitization method to strip out all tags.
const sanitizationConfig = { ALLOWED_TAGS: [] };

class FeedbackProcessor {
  /**
   * Constructor.
   *
   * @param {DocumentClient} db
   *   The DynamoDB document client.
   */
  constructor(db) {
    this.db = db;
  }

  /**
   * Parse the raw data into a format that can be submitted to the database.
   *
   * @param {object} data
   *   The incoming data from the event.
   * @returns {Object}
   *   An object literal whose name-value pairs will become a database record.
   */
  static parseItem(data) {
    // Copy the data parameter into a new variable to mutate during validation.
    const validData = Object.assign({}, data);

    // Define a schema to validate the submitted data.
    const schema = Joi.object().keys({
      // The 'helpful' property is always required.
      helpful: Joi.string().valid(['yes', 'no']).required(),
      // The 'feedback_comment' property is required when helpful is 'no', but
      // is forbidden when 'helpful' has another value.
      feedback_comment: Joi.when('helpful', {
        is: 'no',
        then: Joi.string().required(),
        otherwise: Joi.any().forbidden(),
      }),
      // The extraData properties are all optional, but must have valid
      // data types.
      extraData: Joi.object().keys({
        pageName: Joi.string(),
        submissionType: Joi.string(),
        url: Joi.string().uri(),
        searchPhrase: Joi.string(),
        userId: Joi.number().integer(),
        userRole: Joi.number().integer(),
        orgId: Joi.number().integer(),
      // Allow additional, unspecified extraData properties.
      }).unknown(),
    });
    const validationResult = Joi.validate(data, schema, {
      // Convert numeric strings into numbers for validation purposes.
      convert: true,
      // Do not abort early; evaluate all properties
      // for potential validation errors.
      abortEarly: false,
    });
    if (validationResult.error !== null && Object.prototype.hasOwnProperty.call(validationResult.error, 'details')) {
      const { details } = validationResult.error;
      for (let i = 0, len = details.length; i < len; i += 1) {
        if (details[i].path[0] === 'extraData') {
          // If an extraData child property is invalid, the rest of the
          // submission can be saved after the invalid property is removed.
          const invalidProperty = details[i].path[1];
          delete validData.extraData[invalidProperty];
        } else {
          // If validation fails on a top-level property, the whole record
          // must be rejected. Return a new object with an 'error' property.
          return {
            error: details[i].message,
          };
        }
      }
    }

    const { extraData } = validData;
    const timestamp = validData.timestamp || new Date().getTime();

    const feedback = {
      uuid: uuidv4(),
      created: timestamp,
      updated: timestamp,
    };
    let value;

    // Populate the top-level data properties.
    Object.keys(validData).forEach((key) => {
      // Skip the extraData property; use it in the next for loop.
      if (key !== 'extraData') {
        // Get the sanitized version of the submitted content.
        value = DOMPurify.sanitize(validData[key], sanitizationConfig);

        // Skip empty strings. DynamoDB does not allow empty strings
        // to be submitted as properties.
        if (typeof value === 'string' && value.length === 0) {
          return;
        }
        feedback[key] = value;
      }
    });

    if (extraData !== undefined && typeof extraData === 'object') {
      // Populate the data properties from extraData.
      Object.keys(extraData).forEach((key) => {
        value = DOMPurify.sanitize(extraData[key], sanitizationConfig);
        // DynamoDB does not allow empty strings to be submitted as properties.
        if (typeof value === 'string' && value.length === 0) {
          return;
        }
        feedback[key] = value;
      });
    }
    return feedback;
  }

  /**
   * Save the submitted data to the database.
   *
   * @param {function} callback
   *   The callback function passed into the Lambda handler function.
   * @param {object} data
   *   The incoming raw data from the event.
   * @param {string} stage
   *   The name of the stage, e.g. 'dev', 'qa', 'v1'.
   * @param {object} params
   *   Optional. A set of HTTP request parameters forwarded from API Gateway.
   */
  saveItem(callback, data, stage = 'dev', params = {}) {
    const feedback = FeedbackProcessor.parseItem(data);

    if (Object.prototype.hasOwnProperty.call(feedback, 'error')) {
      // Check if the parsed value of feedback has an 'error' property.
      // If so, validation has failed and the record should not be written
      // to the database. Return an error response.
      const response = {
        statusCode: 400,
        body: feedback.error,
      };
      callback(null, response);
    } else {
      // The feedback contains valid data, proceed with saving to the DB.
      const dynamoParams = {
        TableName: `Feedback${stage}`,
        Item: feedback,
      };

      const response = {};

      this.db.put(dynamoParams, (err) => {
        if (err) {
          response.statusCode = 400;
          response.body = JSON.stringify(err);
          callback(null, response);
        } else {
          const responseBody = {
            message: 'Feedback successfully saved.',
            item: feedback,
            params,
          };
          response.statusCode = 200;
          response.body = JSON.stringify(responseBody);
          callback(null, response);
        }
      });
    }
  }
}

module.exports = FeedbackProcessor;
