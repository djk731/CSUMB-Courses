const AWS = require('aws-sdk');
const FeedbackProcessor = require('./FeedbackProcessor');

/* eslint-disable */
console.log('Starting up customer feedback lambda function.');
/* eslint-enable */
process.env.PATH = `${process.env.PATH}:${process.env.LAMBDA_TASK_ROOT}`;

AWS.config.update({
  region: process.env.AWS_REGION || 'us-east-1',
  apiVersion: '2012-10-08',
});
const dynamodb = new AWS.DynamoDB.DocumentClient();
const processor = new FeedbackProcessor(dynamodb);

// Lambda handler.
exports.handler = (event, context, callback) => {
  // Copy the event parameter into a variable that is safe to mutate.
  const processedEvent = Object.assign({}, event);

  // Initialize the stageVariables if they don't already exist.
  processedEvent.stageVariables = event.stageVariables || {};
  processedEvent.stageVariables.lambdaAlias = event.stageVariables.lambdaAlias || 'v1';

  const data = JSON.parse(processedEvent.body);
  processor.saveItem(callback, data, processedEvent.stageVariables.lambdaAlias);
};
