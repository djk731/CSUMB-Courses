const aws = require('aws-sdk');
const fs = require('fs');
const url = require('url');
const path = require('path');

exports.handler = (event, context, callback) => {
  // Initialize the requestContext and headers if they don't already exist.
  event.requestContext = event.requestContext || {};
  event.headers = event.headers || {};

  if (event.httpMethod === "GET") {
    return serveFiles(event, context, callback);
  } else {
    callback(new Error('Lambda function only accepts GET requests.'));
  }

  // Serve the files
  function serveFiles(event, context, lambdaCallback) {
    // Determine base path on whether the API Gateway stage is in the path or not
    let base_path = '/';
    if (typeof event.requestContext.path !== 'undefined') {
      if (event.requestContext.path.startsWith('/' + event.requestContext.stage)) {
        base_path = '/' + event.requestContext.stage + '/';
      }
    }

    let filePath = path.join(process.env.LAMBDA_TASK_ROOT, 'main.js');
    let func = '';
    // Based on the request event, generate the URL where the React form
    // should post.
    const postUrl = generatePostUrl(event);
    // If the request event had the data needed to generate a postUrl,
    // create a function that returns this URL. The function will be appended
    // to the content of the main.js file before it is served to the browser.
    if (postUrl.length > 0) {
      func = generateApiEndpointFunction(postUrl);
    }
    // Read the file, fill in base_path and serve, or 404 on error
    fs.readFile(filePath, function (err, data) {
      if (err) {
        return done(404, '{"message":"Not Found"}', 'application/json', lambdaCallback);
      }
      let content = data.toString().replace(/{{base_path}}/, base_path) + func;
      return done(200, content, 'application/javascript', lambdaCallback);
    });
  }

  /**
   * Generate a URL where the React app form action will post.
   *
   * @param event
   *   The request event forwarded to the Lambda function.
   * @returns {string}
   *   The URL where the form action will post.
   */
  function generatePostUrl(event) {
    let postUrl = '';
    let postPath = '';

    // If there is no path, return an empty string.
    if (typeof event.requestContext.path !== 'string') {
      return '';
    }
    else {
      postPath = event.requestContext.path;
    }
    if (typeof event.headers['X-Forwarded-Proto'] === 'string') {
      postUrl += event.headers['X-Forwarded-Proto'] + '://';
    }
    else {
      postUrl += 'https://';
    }
    if (typeof event.headers['Host'] === 'string') {
      postUrl += event.headers['Host'];
    }
    postUrl += postPath;

    // Attempt to parse the postUrl string into a URL object.
    const parsedUrl = url.parse(postUrl);
    // Check that the URL object has the required properties to ensure that
    // the url.parse() method validated it is a well-formed URL.
    const requiredUrlProperties = ['protocol', 'host'];
    // If the generated URL is not valid, return an empty string.
    requiredUrlProperties.forEach(function checkUrlProperties(property) {
      if (typeof parsedUrl[property] !== 'string' || parsedUrl[property].length === 0) {
        return '';
      }
    });
    // Return the validated URL.
    return postUrl;
  }

  /**
   * Generate a function to append to the code in the React app.
   *
   * The postUrl parameter is based on the incoming request context,
   * and therefore takes into account the dev/qa/prod environment from which
   * the React app is served, and to which it should also post results. This
   * function will be appended to the code in the React app before the app is
   * sent to the browser, so that the app can call it to get the URL where
   * form submissions should post.
   *
   * @param postUrl
   * @returns {string}
   */
  function generateApiEndpointFunction(postUrl) {
    return `
		function getApiEndpoint() {
			return '${postUrl}';
		}`;
  }

  // We're done with this lambda, return to the client with given parameters
  function done(statusCode, body, contentType, lambdaCallback, isBase64Encoded = false) {
    lambdaCallback(null, {
      statusCode: statusCode,
      isBase64Encoded: isBase64Encoded,
      body: body,
      headers: {
        'Content-Type': contentType
      }
    });

  }
};