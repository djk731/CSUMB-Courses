const serveCustomerFeedbackFiles = require('./index');

describe('Lambda function to serve React app', () => {
  // Set the Lambda task root environment variable for all tests.
  process.env.LAMBDA_TASK_ROOT = process.env.PWD;

  test('Lambda function only accepts GET requests', () => {
    const testEvent = {
      httpMethod: 'POST',
    };
    const context = {};
    serveCustomerFeedbackFiles.handler(testEvent, context, (err, result) => {
      expect(result).toBe(undefined);
      expect(err).toEqual(new Error('Lambda function only accepts GET requests.'));
    });
  });
  test('Lambda function does not append getApiEndpoint() function if path is missing from event object', () => {
    const testEvent = {
      httpMethod: 'GET',
    };
    const context = {};
    serveCustomerFeedbackFiles.handler(testEvent, context, (err, result) => {
      expect(err).toBe(null);
      expect(result.body).not.toContain('getApiEndpoint() {');
    });
  });
  test('Lambda function uses custom domain, protocol, and path when provided', () => {
    const testEvent = {
      requestContext: {
        path: '/voc/v1/customer-feedback',
      },
      headers: {
        'Host': 'qm1drnzzm7.execute-api.us-east-1.amazonaws.com',
        'X-Forwarded-Proto': 'http',
      },
      httpMethod: 'GET',
    };
    const context = {};
    serveCustomerFeedbackFiles.handler(testEvent, context, (err, result) => {
      expect(err).toBe(null);
      expect(result.body).toContain('http://qm1drnzzm7.execute-api.us-east-1.amazonaws.com/voc/v1/customer-feedback');
    });
  });
});
